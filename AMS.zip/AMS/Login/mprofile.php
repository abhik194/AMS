<!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>MCA</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">	

<style>

.admincontent{ margin-left: 270px;  width:800px; height:auto;  background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }


.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}

.stat{
	width:300px;
	height:200px;
	text-align:center;
	background-color:rgba(52,73,94,0.7);
	border-radius:2px
	margin:auto;
	margin-left:-20px;
	padding:5px;
	color:white;
	font-weight:bold;
	font-size:14pt;
	border:2px solid blue;
	border-collapse:collapse;
	th,td{
		border-bottom:1px solid #ddd;
	}
}
.studentlist{clear: both; font-family: sans-serif; margin-left:470px; font-weight:bold; margin-top:100px;
	font-size:14pt;}

.studentlist table td{ background: ivory;padding:9px 22px; width:141px;color:black;}
.studentlist table  th{ background:ivory; padding:9px 22px; width:151px; color:black;}

.studentlist table td:hover{ background: crimson; }
.studentlist table th:hover{ background: crimson; }







</style>

</head>
<body>
	
	<div class="maintext"><hr>
			Admission Status<hr>
		</div>
<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="studentpanel.php"><i class="fa fa-user-circle fa-fw"></i>Student Panel</a>    </li>
				<li  ><a href="mprofile.php"><i class="fa fa-pencil fa-fw "></i>MCA Status</a>    </li>	
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>
	
<div class="studentlist">



<?php
session_start();
include("connection.php");

$student_name = $_SESSION["student_name"];

$sql = "SELECT * FROM bcom WHERE student_name='$student_name'";
$result = mysqli_query($db, $sql);

if($row = mysqli_fetch_array($result)) {
    $student_name = $row["student_name"];
    $status = $row["status"];
    $Email = $row["Email"];

    echo  "
    <table class='stat'>
        <tr><td>Student Name:</td><td>$student_name</td></tr>
        <tr><td>Email:</td><td>$Email</td></tr>
        <tr><td>Admission Confirmation:</td><td>$status</td></tr>
    </table>
    ";
	
}
?>

</div>

	</body>
</html>