<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>



 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Department</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">


<style>




.admincontent{ margin-left: 400px;  width:570px; height:  300px; background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }
.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both; font-family: sans-serif;}
.titlelist ul{list-style-type: none; display: inline; border-radius: 12px 12px 0 0;}
.titlelist ul li{ float:left; background:ivory;width:200px; padding: 9px 8px; border:1px solid black;border-right: none;border-bottom:none; color:black;}
.titlelist ul li:first-child{ width:50px;border-radius: 12px 0 0 0; }
.titlelist ul li:last-child{ border-radius:0 12px 0 0 ;border-right:1px solid black; }

.detaillist ul{ list-style-type: none;display:inline;  font-size:small;}
.detaillist ul li:hover{ background: crimson; }
.detaillist ul li{ float: left; background:ivory; width:200px; max-width: 200px; padding: 9px 8px;border-left:1px solid black; margin-bottom: 3px; color:black;}
.detaillist ul li:first-child{width:50px;clear: both; }
.detaillist ul li:last-child{border-right: 1px solid black;}

.pic{  position:absolute;left:800px; float: left; visibility: hidden;}
.pic img{ border-radius:25px; }
.search button:hover{ cursor: pointer; }



</style>

</head>
<body>


	
	
<div class="maintext"><hr>
			Department Database <hr>
		</div>

<div class="mainHeader">
			<div id="header">
			</div>
			<nav>
			<div align="center">
			<ul>
				<li><a href="studentpanel.php"><i class="fa fa-user-circle fa-fw"></i>Student Panel</a>    </li>
				<li  id ="selectedli"><a href="department.php"><i class="fa fa-book fa-fw"></i>Department</a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent fleft">
			<div>

					<?php 

					

					if(isset($_GET['updated'])){
					echo "<div class='fleft insert sphover'><i class='fa fa-check fa-fw fa-lg'></i>
							".$_GET['updated']."
					</div>";
					}

					?>
					
					<?php 

					

					if(isset($_GET['deleted'])){
					echo "<div class='fleft insert sphover'><i class='fa fa-check fa-fw'></i>
							".$_GET['deleted']."
					</div>";
					}

					?>


			</div>
<center>
			<div class="studentlist">
							<div class="titlelist">
								<ul>
									<li>Sl.no</li>
									<li>Department_ID</li>
									<li>Department Name</li>
								</ul>

							</div>






<?php

$dbname = "AMS";
$username = "root";
$password = "";
$servername = "localhost";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM department";
$result = $conn->query($sql);
$i=1;

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {	$del=$row["did"]; $edit=$row["did"]; 


         echo " <div class='detaillist'>

								<ul >
									<li>".$i."</li>
									
									<li>". $row["did"]  ."</li>
									<li>". $row["dname"]  ."</li>
								</ul>

					</div>
				";
							
				$i++;

         
     								}
	
							} else {
   										  echo "<p>0 results</p>";
									}

$conn->close();

?>
							

							
			</div>
</center>		

		</div>	



	
	


	
</div>


</body>
</html>
