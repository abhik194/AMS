<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="beng.css">
</head>
<style>
a {
	text-decoration:none;
}
</style>
<body>
	<div class="header" align="center">
		<h2>Register</h2>
	</div>
	<div class="yolo">
	<form method="post" action="register.php">

		<?php include('errors.php'); ?>
		
		<div class="form-input">
			<input type="text" name="username" placeholder="Username" value="<?php echo $username; ?>">
		</div>
		<div class="form-input">
			<input type="email" name="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="enter a valid email" value="<?php echo $email; ?>">
		</div>
		<div class="form-input">

			<input type="password" placeholder="Password" name="password_1">
		</div>
		<div class="form-input">
			<input type="password" placeholder="Confirm Password" name="password_2">
		</div>
		<div class="form-input">
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>
		</div>
		<p align="center">
			Already a member? <a href="login.php" style="color:rgb(0,255,0)";>Sign in</a>
		</p>
	</form>
</body>
</html>