 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Status</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href="abhi.css" rel="stylesheet" type="text/css" />

</head>
<body>
	
<div class="maintext"><hr>
			Admission Status <hr>
		</div>
<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li id ="selectedli"><a href="studentpanel.php"><i class="fa fa-user-circle fa-fw"></i>Student Panel</a>    </li>
				<li><a href="mdetails.php"><i class="fa fa-pencil fa-fw "></i>MCA Status</a>    </li>	
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>
</div>


<?php
include("connection.php");

if(isset($_POST["submit"])) {
    $student_name = $_POST["student_name"];
    $Email = $_POST["Email"];

    $sql = "SELECT * FROM bcom 
            WHERE student_name='$student_name' AND Email='$Email'";
    $result = mysqli_query($db, $sql);
    $numRows = mysqli_num_rows($result);
    if($numRows==1) {
        session_start();
        $_SESSION["student_name"] = $student_name;
        header("Location: ./mprofile.php");
    } else {
        echo "Invalid Information provided.";   
    }
}
?>

<div class="salu" align="center">
<form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="post">
</br>
<p><b>Please enter your Name and Email to know your admission Status.</b></p></br></br>
<div class="sal-input">
		<input type="text" placeholder="Student name"  name="student_name">
	<br></div>
	<div class="bal-input">
		<input type="email" placeholder="Email" name="Email">
	<br></div>   
<input id="button" type="submit" name="submit" value="Proceed" class="bt-login" />
</form>
</div>
		
	</body>
</html>