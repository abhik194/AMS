<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>


 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Student Panel</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">	
<link rel="stylesheet" href="./css/style.css" type="text/css">	

<style>


.admincontent{ margin-left: 300px; }

</style>

</head>
<body>


<div class="maintext"><hr>
			Welcome to Student Panel<hr>
		</div>

<div class="mainHeader">
			<div id="header">
			</div>
			<nav>
			<div align="center">
			<ul>
				<li id ="selectedli"><a href="studentpanel.php"><i class="fa fa-user-circle fa-fw"></i>Student Panel</a>    </li>
				<li><a href="mdetails.php"><i class="fa fa-pencil fa-fw "></i>MCA Status</a>    </li>
                <li><a href="bdetails.php"><i class="fa fa-pencil fa-fw "></i>BCA Status</a>    </li>
				<li><a href="course.php"><i class="fa fa-ellipsis-v fa-fw "></i>Course</a></li>
				<li><a href="department.php"><i class="fa fa-ellipsis-v fa-fw "></i>Department</a></li>
				<li><a href="fee.php"><i class="fa fa-ellipsis-v fa-fw "></i>Fee</a></li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent">
		</br><center><h3> Instructions </h3></center>
		</br>
		<ul>
			<li>Admission status can be viewed.</li>
			<li>All the students can view students details.</li>
			<li>Information of Course. </li>
			<li>Fee Structure can be viewed.</li>
			<li>Department Information.</li>
		</ul>
		

		</div>	


</div>
	
	



</body>
</html>