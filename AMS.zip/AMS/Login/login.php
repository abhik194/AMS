<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="yash.css">
</head>
<style>
a {
	text-decoration:none;
}
</style>
<body>

	<div class="header" align="center">
		<h2>Login</h2>
	</div>
	<div class="yolo">
	<img src="images/ben.png">
	<form method="post" action="#">

		<?php include('errors.php'); ?>
		<div class="form-input">
		<input type="text" placeholder="Enter Username"  name="username" required>
	<br></div>
		<div class="form-input">
		<input type="password" placeholder="Enter Password" name="password" required>
	<br></div> 
		<input type="submit" name="login_user" value="Login" class="btn-login" />
	</div>
		
		<p align="center">
			Not yet a member? <a href="register.php" style="color:rgb(0,255,0)"; >Sign up</a>
		</p>
	</form>

</body>
</html>