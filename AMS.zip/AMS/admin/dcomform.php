
<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=Login first then Enter');
}

?>



 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>BCA Insert</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">

<style>
.admincontent{ margin-left: 250px;  width:850px; height:auto; background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }


.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both;}

.studentlist table input , .studentlist table select{ background: white;padding:9px 22px; width:141px;border:none;}
.studentlist table  th{ text-align:left;background:ivory; padding:9px 22px; width:151px; color:black; }
.studentlist table td{ background: white; }
.studentlist table td:hover{ background: crimson; }
.studentlist table th:hover{ background:crimson; }
.studentlist table input:focus{ outline: none; }


.studentlist table select{   padding:12px 22px;width: 188px;}
.option{  color: blue; }

.sbutton button{ margin: 1px; border-radius:6px;cursor: pointer;  font-weight: bolder;padding:10px 24px;}
.center{ text-align: center;  font-family: sans-serif;font-variant: small-caps; }

</style>

</head>
<body>

<div class="maintext"><hr>
			MCA Database <hr>
		</div>
<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li  ><a href="dcomview.php"><i class="fa fa-pencil fa-fw "></i> BCA</a>    </li>	
				<li id ="selectedli"><a href="bcomview.php"><i class="fa fa-book fa-fw"></i> MCA</a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>


		<div class="admincontent fleft">
			<div>


					<div class="fleft insert sphover">
								 <a href="dcomform.php"><i class="fa fa-plus-circle fa-fw"></i> Insert New Record</a>
					</div>
					<div class="fleft insert sphover">
								 <a href="dcomview.php"><i class="fa fa-database fa-fw"></i> BCA Database</a>
					</div>

			</div>

			<div class="studentlist">
							
<?php
// Variables
if(isset($_POST['submit'])){
$User = "root";
$Password = "";
$Database = "ams";
$Table = "dcom";
$Host = "localhost";
$sqlDate = date('Y-m-d H:i:s'); 

		// Connect to the server
		$db = mysqli_connect('localhost', 'root', '', 'ams');



		$upload_image=$_FILES["myimage"]["name"];  //image name

		$folder="Photo/";  // folder name where image will be store
		move_uploaded_file($_FILES["myimage"]["tmp_name"], "$folder".$_FILES["myimage"]["name"]);
		// Insert data into DB
	
		$insert = "INSERT INTO $Table (Student_Name, Father_Name, Birth_Date,
										  Email, Gender, Address, City,
										  State, Matric_Board,
										  Matric_Percentage,Matric_PassingOfYear ,
										  image_name ,image_path ,Registration_Date ) 
					  VALUES($_POST[sname]', '$_POST[fname]',  '$_POST[dob]'
							, '$_POST[email]', '$_POST[gender]', '$_POST[address]', '$_POST[city]'
							, '$_POST[state]', '$_POST[Matric_Board]'
							, '$_POST[Matric_Percentage]', '$_POST[Matric_PassingOfYear]'
							, '$upload_image','$folder','$sqlDate')";		
		
	if (!mysqli_query($db, $insert)){
	die("Error:".mysqli_error());
}
else echo "<div class='insert'><center> <p >  Record Added Successfully  <br>";
	echo "Student name is:<strong>";
	echo $_POST['sname'];
	echo "</strong></p></center></div>";
	
		mysqli_close($db); 
	}
		
?>

	
					<div class='insert sphover center' id="error">
						BCA New Student
					</div>
			<table>
			<form method="post" action="dcomform.php" enctype="multipart/form-data">
			<tr ><th>Student Name</th><td><input type="text" name="sname" maxlength="50" required/></td>
				<th>Upload Image</th><td><input  type="file" name="myimage" required/></td></tr>


			<tr><th>Father Name</th><td><input type="text" name="fname" maxlength="50"  required /></td>
			
			<th>Course</th><td><input type="text" name="class"  disabled value="BCA" /></td>
			</tr>
			<tr><th>Email</th><td><input type="email" name="email"  id="email" onchange="checkemail(this.value)" onblur ="checkemail(this.value)"  /></td>
			<th>Birth Date</th><td><input type="date" name="dob" id="bd" min="1990-01-01" max="2005-12-12" required/></td></tr>

			<tr><th>Registration Date</th><td><input type="text" id="date" name="reg_date" /></td><th>Gender</th><td>	<select name="gender">
																										<option class="option"> Male</option>
																										<option class="option">Female</option>
																							</select></td></tr>
			<tr><th>City</th><td><input type="text" name="city" maxlength="30" required/></td>
					<th>State</th><td><input type="text" name="state" maxlength="30" required/></td></tr>
				<th>SSC_Board</th><td><input type="text" name="Matric_Board" placeholder="Board Name" maxlength="30" required /></td>
			<th>SSC_Percentage</th><td><input type="text" name="Matric_Percentage" maxlength="30" placeholder=Percentage required/></td>
				<tr><th>SSC_PassingOfYear</th><td><input type="text" name="Matric_PassingOfYear" maxlength="30" placeholder="Year Of Passing" required /></td></tr>
			
			<tr><th>Address</th><td colspan=3><input type="text" name="address" required  style="width: 535px;"  /></td></tr>

		

			<div class="sbutton"><center><button class="sphover" type="submit" name="submit"> Register </button><button class="sphover" type="reset">Reset</button></center></div>
			</form>	</table> 
			</div>

		</div>	


</div>
	
	

</body>
</html>

<script>
var d = new Date();
document.getElementById("date").value = d.toDateString();
</script>

<!--<script type="text/javascript">
	function check(rollno){
	var flag;

	dom = document.getElementById('error').style;

if (rollno.length == 0) {dom.color="black";
					dom.fontSize="12pt";
					document.getElementById("error").innerHTML='BCA New Student';
					return;}
else if(rollno>500){  return;}


else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                flag = xmlhttp.responseText;
            	if(flag==1){
            		document.getElementById("rollno").value="";
            		document.getElementById("rollno").focus();

            		dom.color="red";
            		dom.fontSize="14pt";
          			document.getElementById("error").innerHTML='Roll No already exist..!';

						}
				else{
					dom.color="black";
					dom.fontSize="12pt";
					document.getElementById("error").innerHTML='BCA New Student';
				}
   
            }
        };
        xmlhttp.open("GET", "existing.php?rollno=" + rollno, true);
        xmlhttp.send();
    }
}
</script>-->


<script type="text/javascript">
	function checkemail(email){
	var flag;

	dom = document.getElementById('error').style;

if (email.length == 0) {  dom.color="black";
					dom.fontSize="12pt";
					document.getElementById("error").innerHTML='BCA New Student';return;}

else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                flag = xmlhttp.responseText;
            	
            	if(flag==1){
            		document.getElementById("email").value="";
            		document.getElementById("email").focus();
            		dom.color="red";
            		dom.fontSize="14pt";
          			document.getElementById("error").innerHTML='Email already exist..!';

						}
				else{
					dom.color="black";
					dom.fontSize="12pt";
					document.getElementById("error").innerHTML='BCA New Student';
				}
   
            }
        };
        xmlhttp.open("GET", "existing.php?email=" + email, true);
        xmlhttp.send();
    }
}
</script>