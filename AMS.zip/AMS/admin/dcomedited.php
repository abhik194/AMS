<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=login first then come');
}

?>


<?php

$db = mysqli_connect('localhost', 'root', '', 'ams');

$edit_record = $_GET['edit'];

$query = "SELECT * FROM dcom WHERE s_id='$edit_record'";

$run = mysqli_query($db, $query);

while ($row=mysqli_fetch_array($run) )
{
	$s_id 		 = $row['s_id'];
	$student_name = $row['student_name'];
	$father_name = $row['father_name'];
	$Birth_Date  = $row['Birth_Date'];
	$Email		 = $row['Email'];
	$Address	 = $row['Address'];
	$status		 = $row['status'];
	$City  		 = $row['City'];
	$State 		 = $row['State'];
	$Matric_Board 			 = $row['Matric_Board'];
	$Matric_Percentage   	 = $row['Matric_Percentage'];
	$Matric_PassingOfYear 	 = $row['Matric_PassingOfYear'];
	$inter_course 			 = $row['inter_course'];
	$inter_board 			 = $row['inter_board'];
	$inter_percentage   	 = $row['inter_percentage'];
	$inter_year 			 = $row['inter_year'];
	
}

?>


 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Edit</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">

<style>

.admincontent{ margin-left: 270px;  width:800px; height:auto;  background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }


.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both;}

.studentlist table input , .studentlist table select{ background: white;padding:9px 22px; width:141px;border:none;}
.studentlist table  th{ text-align:left;background:ivory; padding:9px 22px; width:151px; color:black;}
.studentlist table td{ background: white; }
.studentlist table td:hover{ background: crimson; }
.studentlist table th:hover{ background: crimson; }
.studentlist table input:focus{ outline: none; }


.studentlist table select{   padding:12px 22px;width: 188px;}
.option{  color: blue; }

.sbutton button{ margin: 1px; border-radius:6px;cursor: pointer;  font-weight: bolder;padding:10px 24px;}
.center{ text-align: center;  font-family: sans-serif;font-variant: small-caps; }



</style>

</head>
<body>
	
<div class="maintext"><hr>
			MCA Database <hr>
		</div>
	<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li><a href="dcomview.php"><i class="fa fa-pencil fa-fw "></i> BCA</a>    </li>	
				<li    id ="selectedli"><a href="bcomview.php"><i class="fa fa-book fa-fw"></i>MCA</a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent fleft">
			<div>


					<div class="fleft insert sphover">
								 <a href="bcomform.php"><i class="fa fa-plus-circle fa-fw"></i> Insert New Record</a>
					</div>
					<div class="fleft insert sphover">
								 <a href="bcomview.php"><i class="fa fa-database fa-fw"></i> MCA Database</a>
					</div>
					<div class="search fright ">
						<form action="dcomsearch.php" method="GET">

							<input type="text" name="search" placeholder="Search" />
							<button type="submit" name="submit" value="Search" ><i class="fa fa-search"></i></button>
						</form>
					</div>

			</div>

			<div class="studentlist">
							

	
					<div class='insert sphover center'>
						MCA Student Update
					</div>
			<table>
			<form method="post" action="dcomedited.php?edited_form=<?php echo $s_id;?>" enctype="multipart/form-data">
			<tr ><th>Student Name</th><td><input type="text" name="student_name1" value="<?php echo $student_name;?>" maxlength="50" required/></td>
				<th>Upload Image</th><td><input  type="file" name="myimage" /></td></tr>


			<tr><th>Father Name</th><td><input type="text" name="father_name1" value="<?php echo $father_name;?>" maxlength="50"  required /></td>
			
			<th>Course</th><td><input type="text" name="class"  disabled value="MCA" /></td>
			</tr>
			<tr><th>Email</th><td><input type="email" name="Email1" value="<?php echo $Email;?>"  /></td>
			<th>Birth Date</th><td><input type="date" name="Birth_Date1"  value="<?php echo $Birth_Date?>"   required/></td></tr>


			
			<tr><th>Registration Date</th><td><input type="text" id="date" name="reg_date" /></td><th>Gender</th><td>	<select name="Gender1">
																										<option class="option"> Male</option>
																										<option class="option">Female</option>
																							</select></td></tr>
			<tr><th>City</th><td><input type="text" name="City1" maxlength="30" value="<?php echo $City;?>" required/></td>
					<th>State</th><td><input type="text" name="State1" maxlength="30" value="<?php echo $State;?>" required/></td></tr>
				<th>SSC_Board</th><td><input type="text" name="Matric_Board1" value="<?php echo $Matric_Board;?>" maxlength="30" required /></td>
			<th>SSC_Percentage</th><td><input type="text" name="Matric_Percentage1" value="<?php echo $Matric_Percentage;?>" required/></td>
				<tr><th>SSC_Passing Of Year</th><td><input type="text" name="Matric_PassingOfYear1" value="<?php echo $Matric_PassingOfYear;?>" required /></td>
				<th>Confirm Student</th><td><select name="status1"><option class="option">Confirm</option>
																  <option class="option">Not Confirm</option>
																							</select></td>
				</tr>
			
			<tr><th>Address</th><td colspan=3><input type="text" name="Address1" value="<?php echo $Address;?>" required  style="width: 535px;"  /></td></tr>

			

			<div class="sbutton"><center><button class="sphover" type="submit" name="submit"> Update </button><button class="sphover" type="reset">Reset</button></center></div>
			</form></table> 
			</div>

		</div>	


</div>
	



</body>
</html>

<script>
var d = new Date();
document.getElementById("date").value = d.toDateString();
</script>

<?php
if(isset($_POST['submit']))
{
	$edited_id 			= $_GET['edited_form'];
	$student_name1		= $_POST['student_name1'];
	$father_name1		= $_POST['father_name1'];
	$Birth_Date1		= $_POST['Birth_Date1'];
	$Email1				= $_POST['Email1'];
	$Gender1			= $_POST['Gender1'];
	$Address1			= $_POST['Address1'];
	$status1			= $_POST['status1'];
	$City1				= $_POST['City1'];
	$State1				= $_POST['State1'];
	$Matric_Board1		= $_POST['Matric_Board1'];
	$Matric_Percentage1		= $_POST['Matric_Percentage1'];
	$Matric_PassingOfYear1	= $_POST['Matric_PassingOfYear1'];


		$upload_image=$_FILES["myimage"]["name"];  //image name

		$folder="Photo/";  // folder name where image will be store
		move_uploaded_file($_FILES["myimage"]["tmp_name"], "$folder".$_FILES["myimage"]["name"]);


	$query1 = "UPDATE dcom SET 
								student_name='$student_name1',
								father_name='$father_name1',
				
								Birth_Date='$Birth_Date1',
								Email='$Email1',
								Gender='$Gender1',
								Address='$Address1',
								City='$City1',
								State='$State1',
								status='$status1',
								Matric_Percentage='$Matric_Percentage1',
								Matric_PassingOfYear='$Matric_PassingOfYear1',
								Matric_Board='$Matric_Board1',
								image_path = '$folder' ,
								image_name = '$upload_image'

							WHERE s_id=$edited_id ";
	if(mysqli_query($db, $query1))
	{
		echo "<script>window.open('bcomview.php?updated=Record Updated successfully','_self')</script>";}
		else  echo mysqli_error($db);	




}
	
	
	?>