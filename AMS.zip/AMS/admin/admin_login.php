<?php

session_start();

?>

<!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Administrator Login</title>

<link rel="stylesheet" type="text/css" href="sal.css">

<!--<link rel="stylesheet" href="./css/style.css" type="text/css">-->



</head>
<body>

<div class="hell" align="center">
	<div class="headtext marginl sphover" align="center">
			<center><h3>Admin Login</h3></center>
					</div>
					<div>
					<form action='admin_login.php' method='POST'>

	<div class="container">
	<img src="images/men.png">
	<form action='admin_login.php' method='POST'>
	<div class="form-input">
		<input type="text" placeholder="Enter Username"  name="user_name" required>
	<br></div>
	<div class="form-input">
		<input type="password" placeholder="Enter Password" name="admin_pass" required>
	<br></div>      
    <input id="button" type="submit" name="login" value="Login" class="btn-login" />
	</div>
	<center>
	<div id="wrong" style="color:red;font-weight:bold"></div>
	<?php if(isset($_GET['error'])){echo $_GET['error']; }?>  
	</center>
	</div>
	</form>

					</div>


</div>


<?php

$db = mysqli_connect('localhost', 'root', '', 'ams');
		
if(isset($_POST['login']))
{
	$username = $_SESSION['user_name'] = $_POST['user_name'];
	$password = $_POST['admin_pass'];

$query = "select * from admin where user_name='$username' AND user_password='$password'";
$run = mysqli_query($db, $query);

if(mysqli_num_rows($run)>0)
{
	echo "<script>window.open('adminpanel.php?logged=logged in successfully','_self')</script>";	
}
else{
echo "<script>document.getElementById('wrong').innerHTML=' You have Incorrect user name or password Retry...!';</script>";
}
	
}



?>

</body>
</html>













