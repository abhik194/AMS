<?php 

if(isset($_POST['submit'])){
$User = "root";
$Password = "";
$Database = "ams";
$Table = "bcom";
$Host = "localhost";

$insert = "INSERT INTO $Table(status)
 ?>