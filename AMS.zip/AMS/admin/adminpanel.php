<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=login first then come');
}

?>


 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Admin Panel</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">	
</head>
<body>


<div class="maintext"><hr>
			Welcome <?php echo $_SESSION['user_name'];?> to Admin Panel<hr>
		</div>

<div class="mainHeader">
			<div id="header">
			</div>
			<nav>
			<div align="center">
			<ul>
				<li id ="selectedli"><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li><a href="dcomview.php"><i class="fa fa-pencil fa-fw "></i>BCA</a>    </li>	
				<li><a href="bcomview.php"><i class="fa fa-book fa-fw"></i> MCA</a>    </li>
				<li><a href="course.php"><i class="fa fa-ellipsis-v fa-fw "></i>Add Course</a></li>
				<li><a href="department.php"><i class="fa fa-ellipsis-v fa-fw "></i>Add Department</a></li>
				<li><a href="fee.php"><i class="fa fa-ellipsis-v fa-fw "></i>Fee</a></li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent" align="center">
		<br/>
		<center><h3> Instructions </h3></center>
		<ul>
			<li> Be carefull while modifying data.</li>
			<li> Once you have entered wrong information , you can edit and delete it.</li>
			<li> When you are inserting a new record don't forget to give them a valid Roll no.</li>
			<li> Once a record is deleted then it will not be undo.</li>
			<li> With form submission, Registration date will be stored in database automatically.</li>
		</ul>
		

		</div>	


</div>
	
	



</body>
</html>