
<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=login first then come');
}

?>



 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>MCA</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">

<style>

.admincontent{ margin-left: 270px;  width:800px;min-height:  380px; background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }
.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both; font-family: sans-serif;}
.titlelist ul{list-style-type: none; display: inline; border-radius: 12px 12px 0 0;}
.titlelist ul li{ float:left; background:ivory;width:150px; padding: 9px 8px; border:1px solid black;border-right: none;border-bottom:none; color:black;}
.titlelist ul li:first-child{ width:50px;border-radius: 12px 0 0 0; }
.titlelist ul li:last-child{ border-radius:0 12px 0 0 ;border-right:1px solid black; }

.detaillist ul{ list-style-type: none;display:inline;  font-size:small;}
.detaillist ul li:hover{ background: crimson; }
.detaillist ul li{ float: left; background:ivory; width:150px; max-width: 150px; padding: 9px 8px;border-left:1px solid black; margin-bottom: 3px; color:black;}
.detaillist ul li:first-child{width:50px;clear: both; }
.detaillist ul li:last-child{border-right: 1px solid black;}

.msg{ background:white; padding:14px 10px; width:50%;color:blue; border:2px solid white; border-radius:30%;}

</style>

</head>
<body>

<div class="maintext"><hr>
			MCA Database <hr>
		</div>
<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li ><a href="dcomview.php"><i class="fa fa-pencil fa-fw "></i> BCA </a>    </li>	
				<li id ="selectedli"><a href=""><i class="fa fa-book fa-fw"></i> MCA </a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent fleft">
			<div>


					<div class="fleft insert">
								 <a href="bcomform.php"><i class="fa fa-plus-circle fa-fw"></i> Insert New Record</a>
					</div>

					<div class="search fright">
						<form action="bcomsearch.php" method="GET">

							<input type="text" name="search" placeholder="Search" />
							<button type="submit" name="submit" value="Search" ><i class="fa fa-search"></i></button>
						</form>
					</div>

			</div>
<center>
			<div class="studentlist">
							<div class="titlelist">
								<ul>
									<li>Sl.no</li>
									
									<li>Student Name</li>
									<li>Father Name</li>
									<li><i class="fa fa-gear fa-fw"></i> Modification</li>
								</ul>

							</div>	

<?php

if(isset($_GET['search'])){
	
		$db = mysqli_connect('localhost', 'root', '', 'ams');
		
		$search_rec = $_GET['search'];
		$search_query = "select * from bcom where student_name='$search_rec'  ";
		
		
		$i=1;
		
		$run2 = mysqli_query($db, $search_query);
		$run3 = mysqli_query($db, $search_query);
		
		$check=mysqli_fetch_assoc($run3);
			if($check==false)
			{
				echo "<br><br><div class='msg'> <i class='fa fa-times fa-lg fa-fw'></i>No result found for :". $_GET['search']."</div>";
			}
		while ($row=mysqli_fetch_assoc($run2))
		{$del=$row["sid"]; $edit=$row["sid"];$det=$row["sid"];


         echo " <div class='detaillist'>

								<ul >
									<li>".$i."</li>
									
									<li>". $row["student_name"]  ."</li>
									<li>". $row["father_name"]  ."</li>
									<li>
										<a href='bcomedited.php?edit=$edit'><i class='fa fa-edit fa-lg fa-fw'></i></a>
										<a href='bcomdelete.php?del=$del'><i class='fa fa-remove fa-lg fa-fw'></i></a>
										<a href='bcomdetail.php?detail=$det'><i class='fa fa-info-circle fa-lg fa-fw'></i></a>
									</li>
								</ul>

					</div>
				";
				$i++;
			}
		}
?>




			</div>
</center>		

		</div>	


</div>
	

</body>
</html>
