<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=login first then come');
}

?>


 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>MCA</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">	

<style>

.admincontent{ margin-left: 270px;  width:800px; height:auto;  background:darkslategray; padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }


.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both;}

.studentlist table td{ background: ivory;padding:9px 22px; width:141px;color:black;}
.studentlist table  th{ background:ivory; padding:9px 22px; width:151px; color:black;}

.studentlist table td:hover{ background: crimson; }
.studentlist table th:hover{ background: crimson; }






</style>

</head>
<body>
	
	<div class="maintext"><hr>
			MCA Database <hr>
		</div>
<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li  ><a href="dcomview.php"><i class="fa fa-pencil fa-fw "></i> BCA</a>    </li>	
				<li id ="selectedli"><a href="bcomview.php"><i class="fa fa-book fa-fw"></i> MCA</a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent fleft">
			<div>


					<div class="fleft insert sphover">
								 <a href="bcomform.php"><i class="fa fa-plus-circle fa-fw"></i> Insert New Record</a>
					</div>
					<div class="fleft insert sphover">
								 <a href="bcomview.php"><i class="fa fa-database fa-fw"></i> All Student Database</a>
					</div>
					<div class="search fright ">
						<form action="bcomsearch.php" method="GET">

							<input type="text" name="search" placeholder="Search" />
							<button type="submit" name="submit" value="Search" ><i class="fa fa-search"></i></button>
						</form>
					</div>

			</div>

			<div class="studentlist">
							
<?php
if(isset($_GET['detail'])){
$did = $_GET['detail'] ;


$db = mysqli_connect('localhost', 'root', '', 'ams');

$dquery = "SELECT * FROM bcom where sid='$did'";
$drun = mysqli_query($db, $dquery);

while($row1=mysqli_fetch_array($drun))
{
	
echo " <div class='insert sphover'>
						<center>Student Details<center/>
					</div>
			<table>

		<tr ><th>Student Name</th><td>". $row1["student_name"] ."</td>


			
			<td rowspan=7 colspan=2 style='background:none;'><center><img src='". $row1["image_path"] . $row1["image_name"] ."' alt='". $row1["image_name"] ."' style='height:350px; width:250px;' ></center></td></tr>

			<tr><th>Father Name</th><td>"	. $row1["father_name"] ."</td></tr>

			<tr><th>Course</th><td>"			. $row1["class"] ."</td></tr>
			
			<tr><th>Email</th><td>"			. $row1["Email"] ."</td></tr>
			<tr><th>Birth Date</th><td>"	. $row1["Birth_Date"] ."</td></tr>

			<tr><th>Registration_Date</th><td>". $row1["Registration_Date"] ."</td></tr>
            <tr><th>Gender</th><td>". $row1["Gender"] ."</td></tr>
			<tr><th>City</th><td>". $row1["City"] ."</td><th>State</th><td>". $row1["State"] ."</td></tr>
			<tr><th>SSC_Percentage</th><td>". $row1["Matric_Percentage"] ."</td><th>SSC_Passing Of Year</th><td>". $row1["Matric_PassingOfYear"] ."</td></tr>
			<tr><th>HSC_Stream</th><td>". $row1["inter_course"] ."</td><th>HSC_Board</th><td>". $row1["inter_board"] ."</td></tr>
			<tr><th>HSC_Percentage</th><td>". $row1["inter_percentage"] ."</td><th>HSC_Passing Year</th><td>". $row1["inter_year"] ."</td></tr>
		
			<tr><th>Address</th><td colspan=3>". $row1["Address"] ."</td></tr>
			</table> 


				";
	}


}


?>






							

							
							


			</div>
		

		</div>	


</div>
	
</body>
</html>

