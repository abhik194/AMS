<?php
session_start();

if(!$_SESSION['user_name']){
	header('location:admin_login.php?error=login first then come');
}

?>



 
 <!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Insert</title>
<link href="font-awesome.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="./css/style.css" type="text/css">
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="./css/style.css" type="text/css">
<style>

.admincontent{ margin-left: 250px;  width:850px; height:auto; background:darkslategray;padding: 14px; border:1px solid blue; border-left:none;border-radius:0 12px 0 0px }


.search input{ width:111px;border-right: none;border-radius:12px 0 0 12px ; }
.search button{ border-left:none;border-radius:0 12px 12px 0 ;}
.insert{ border-radius: 12px; }
.admincontent div{margin:11px 4px;}


.studentlist{clear: both;}

.studentlist table input , .studentlist table select{ background: white;padding:9px 22px; width:141px;border:none;}
.studentlist table  th{ text-align:left;background:ivory; padding:9px 22px; width:151px; color:black; }
.studentlist table td{ background: white; }
.studentlist table td:hover{ background: crimson; }
.studentlist table th:hover{ background:crimson; }
.studentlist table input:focus{ outline: none; }


.studentlist table select{   padding:12px 22px;width: 188px;}
.option{  color: blue; }

.sbutton button{ margin: 1px; border-radius:6px;cursor: pointer;  font-weight: bolder;padding:10px 24px;}
.center{ text-align: center;  font-family: sans-serif;font-variant: small-caps; }


</style>

</head>
<body>

<div class="maintext"><hr>
			Department Database <hr>
		</div>

<div class="mainHeader" >

		<div class="header">
		</div>
		<nav>
			<div align="center">
			<ul>
				<li><a href="adminpanel.php"><i class="fa fa-user-circle fa-fw"></i>Admin Panel</a>    </li>
				<li id ="selectedli"><a href="department.php"><i class="fa fa-book fa-fw"></i> Add Department</a>    </li>
				<li><a href="logout.php"><i class="fa fa-sign-out fa-fw fa-lg " aria-hidden="true"></i>Sign Out</a></li>
			</ul>
		</div>
		</nav>

		<div class="admincontent fleft">
			<div>


					<div class="fleft insert sphover">
								 <a href="departmentform.php"><i class="fa fa-plus-circle fa-fw"></i> Insert New Department</a>
					</div>
					

			</div>

			<div class="studentlist">
							
<?php
// Variables
if(isset($_POST['submit'])){
$User = "root";
$Password = "";
$Database = "ams";
$Table = "department";
$Host = "localhost";
$sqlDate = date('Y-m-d H:i:s'); 

		// Connect to the server
		$db = mysqli_connect('localhost', 'root', '', 'ams');


		// Insert data into DB
	
		$insert = "INSERT INTO $Table (did, dname ) 
					  VALUES('$_POST[did]', '$_POST[dname]')";		
		
	if (!mysqli_query($db, $insert)){
	die("Error:".mysql_error());
}
else echo "<div class='insert'><center> <p >  Record Added Successfully  <br>";
	echo "Department name is:<strong>";
	echo $_POST['dname'];
	echo "</strong></p></center></div>";
	
		mysqli_close($db); 
	}
		
?>

	
<div class='insert sphover center'>
					 New Department
					</div>
			<table>
			<form method="post" action="departmentform.php" enctype="multipart/form-data">
			<tr ><th>Department_ID</th><td><input type="text" name="did" maxlength="50" required/></td>
				</tr>


			<tr><th>Department Name</th><td><input type="text" name="dname" maxlength="50"  required /></td>
			</tr>
		


			

			</table> 

			<div class="sbutton"><center><button class="sphover" type="submit" name="submit"> Enter </button><button class="sphover" type="reset">Reset</button></center></div>
			</form>
			

			</div>
		

		</div>	


</div>
	
	



</body>
</html>

<script>
var d = new Date();
document.getElementById("date").value = d.toDateString();
</script>

