
<!DOCTYPE html>

<html>
<head>
	<meta charset="UTF-8">
	<title>Student Registration</title>
<link href="./font-awesome/css/font-awesome.css" rel="stylesheet" />

<link rel="stylesheet" href="./css/style.css" type="text/css">	

<style>

 .star{
        color:red
    }
    
a {
	text-decoration:none;
}

.frm{  background:darkslategray; border-radius:30px;width:500px;padding:50px 50px ;margin:auto;font-family:rokkittbold}
.inpt{color:white;margin:22px 22px; padding:10px; border-radius:30px;font-family:rokkittbold}
.inpt input{ ; padding-left:22px;float:right;font-family:rokkittbold}
label{color:white; float:left;}
#h22{ text-align:center; margin-top:0px; color:white;}
select{float:right;}

body{
	background-image: url(images/sal3.jpg);
	background-repeat: no-repeat;
	background-size: 100% 1200px;
}

.bttn{ background:#2ECC71; padding:10px 22px ;border-radius:22px; width:122px;margin-left:144px; }
.bttn input{ border:none; background:none;color:black;font-weight:bold;font-family:rokkittbold;font-size:16px;}
.bttn input:hover{ color:black;}
@media only screen and (max-width:993px){
.frm{ margin-left:0;background:blue;}
}
</style>


</head>
<body>

<!-----------------------------form page content----------------->
<!---------------------------------------------------------->
<?php
// Variables
if(isset($_POST['submit'])){
$User = "root";
$Password = "";
$Database = "ams";
$Table = "bcom";
$Host = "localhost";
$sqlDate = date('Y-m-d H:i:s'); 

		// Connect to the server
			$db = mysqli_connect('localhost', 'root', '', 'ams');


		$upload_image=$_FILES["myimage"]["name"];  //image name

		$folder="Photo/";  // folder name where image will be store
		move_uploaded_file($_FILES["myimage"]["tmp_name"], "$folder".$_FILES["myimage"]["name"]);
		// Insert data into DB
	
		$insert = "INSERT INTO $Table (Student_Name, Father_Name, Birth_Date,
										  Email, Gender, Address, City,
										  State, Matric_Board,
										  Matric_Percentage,Matric_PassingOfYear , inter_course,
										  inter_board,inter_percentage,inter_year,
										  image_name ,image_path ,Registration_Date ) 
					  VALUES('$_POST[sname]', '$_POST[fname]', '$_POST[dob]'
							, '$_POST[email]', '$_POST[gender]', '$_POST[address]', '$_POST[city]'
							, '$_POST[state]', '$_POST[Matric_Board]'
							, '$_POST[Matric_Percentage]', '$_POST[Matric_PassingOfYear]','$_POST[inter_course]'
							, '$_POST[inter_board]','$_POST[inter_percentage]','$_POST[inter_year]'
							, '$upload_image','$folder','$sqlDate')";		
		
	if (!mysqli_query($db, $insert)){
	die("Error:".mysqli_error());
}
else echo "<center> <p >  Record Added Successfully  <br>";
	echo "Student name is:<strong>";
	echo $_POST['sname'];
	echo "</strong></p></center>";
	header('location:../index.html');
		mysqli_close($db); 
	}
		
?>
<br>
<div class="frm">
<form action="bcomformo.php" method="POST" enctype="multipart/form-data">
    <center>   <a href="../index.html" style="color:rgb(0,255,0)">HOME</a></center></br>
<h2 id="h22">REGISTRATION FORM</h2>
<div class="inpt">
<label> Student Photo </label><span class="star">*</span> <input type="file" name="myimage" required/>
<br><hr>
<label> Student Name </label><span class="star">*</span> <input type="text" name="sname" maxlength="50" required/>
<br><hr>
<label> Father Name</label><span class="star">*</span> <input type="text" name="fname" maxlength="50" required/>
<br><hr>
<label> Date of Birth</label><input type="date" name="dob"  placeholder="MM/DD/YYYY" required/>
<br><hr>

<label>Email</label><input type="email" name="email"  />
<br><hr>
<label>Gender</label><br><br>

<label>Male<input  type="radio" name="gender" value="Male" checked="checked" /></label>

<label>Female<input  type="radio" name="gender" value="Female" /></label>
<br> <hr>
<label> Address</label><textarea name="address" rows="4" cols="50"></textarea>
<br><hr>
<label>City</label><input type="text" name="city" maxlength="50" required/>
<br><hr>
<label>State</label><input type="text" name="state" maxlength="30" required/>
<br><hr>

<label>Qualifications</label><span class="star">*</span>
<br>

 <br>
<label>SSC Qualification</label>

<input type="text" name="Matric_Board" placeholder="Board Name" maxlength="30" required /><br><br>
<input type="text" name="Matric_Percentage" maxlength="30" placeholder=Percentage required/><br><br>
<input type="text" name="Matric_PassingOfYear" maxlength="30" placeholder="Year Of Passing" required />
<br><hr>
<label>HSC Qualification</label>

<input type="text" name="inter_course" placeholder="Arts/Science" maxlength="30" required /><br><br>
<input type="text" name="inter_board" placeholder="Board/University/clg" maxlength="30" required /><br><br>
<input type="text" name="inter_percentage" maxlength="30" placeholder=Percentage required/><br><br>
<input type="text" name="inter_year" maxlength="30" placeholder="Year Of Passing" required />
<br><hr>

</div>
<br><br>

    
<div class="bttn"><center><input type="submit" name="submit" value="Register"/></center>
    </div><br>
   
<div class="bttn"><center><input  type="reset" value="Reset"/></center></div>



</div>
</form>



</body>
</html>
